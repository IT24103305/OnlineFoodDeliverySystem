package com.fooddelivery.payment;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class PaymentService {
    private List<PaymentMethod> paymentMethods;
    private List<Transaction> transactionHistory;
    private List<Invoice> invoices;

    public PaymentService() {
        this.paymentMethods = new ArrayList<>();
        this.transactionHistory = new ArrayList<>();
        this.invoices = new ArrayList<>();
    }

    // CRUD operations for Payment Methods
    public void addPaymentMethod(PaymentMethod method) {
        paymentMethods.add(method);
    }

    public List<PaymentMethod> getPaymentMethods() {
        return new ArrayList<>(paymentMethods);
    }

    public boolean updatePaymentMethod(String methodId, PaymentMethod updatedMethod) {
        for (int i = 0; i < paymentMethods.size(); i++) {
            if (paymentMethods.get(i).getMethodId().equals(methodId)) {
                paymentMethods.set(i, updatedMethod);
                return true;
            }
        }
        return false;
    }

    public boolean removePaymentMethod(String methodId) {
        return paymentMethods.removeIf(method -> method.getMethodId().equals(methodId));
    }

    // Transaction Management
    public Transaction processPayment(Order order, String methodId) {
        PaymentMethod method = paymentMethods.stream()
                .filter(pm -> pm.getMethodId().equals(methodId))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Payment method not found"));

        Transaction transaction = new Transaction(
                "TX-" + System.currentTimeMillis(),
                order.getOrderId(),
                order.getCustomerId(),
                order.getTotalAmount(),
                new Date(),
                "PROCESSING"
        );

        // Simulate payment processing
        try {
            Thread.sleep(1000); // Simulate network delay
            transaction.setStatus("COMPLETED");
            transactionHistory.add(transaction);
            
            // Generate invoice
            generateInvoice(transaction, order);
            
            return transaction;
        } catch (InterruptedException e) {
            transaction.setStatus("FAILED");
            transactionHistory.add(transaction);
            throw new PaymentProcessingException("Payment processing interrupted", e);
        }
    }

    // Invoice Management
    public Invoice generateInvoice(Transaction transaction, Order order) {
        Invoice invoice = new Invoice(
                "INV-" + System.currentTimeMillis(),
                transaction.getTransactionId(),
                order.getCustomerId(),
                order.getItems(),
                order.getTotalAmount(),
                new Date(),
                "GENERATED"
        );
        
        invoices.add(invoice);
        return invoice;
    }

    public List<Invoice> getInvoicesForCustomer(String customerId) {
        List<Invoice> customerInvoices = new ArrayList<>();
        for (Invoice invoice : invoices) {
            if (invoice.getCustomerId().equals(customerId)) {
                customerInvoices.add(invoice);
            }
        }
        return customerInvoices;
    }

    // Reporting
    public double getTotalRevenue() {
        return transactionHistory.stream()
                .filter(t -> t.getStatus().equals("COMPLETED"))
                .mapToDouble(Transaction::getAmount)
                .sum();
    }
}