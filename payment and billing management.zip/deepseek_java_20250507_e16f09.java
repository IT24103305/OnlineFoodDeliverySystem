package com.fooddelivery.payment;

import java.util.Date;

public class Transaction {
    private String transactionId;
    private String orderId;
    private String customerId;
    private double amount;
    private Date transactionDate;
    private String status; // "PROCESSING", "COMPLETED", "FAILED"

    public Transaction(String transactionId, String orderId, String customerId, 
                     double amount, Date transactionDate, String status) {
        this.transactionId = transactionId;
        this.orderId = orderId;
        this.customerId = customerId;
        this.amount = amount;
        this.transactionDate = transactionDate;
        this.status = status;
    }

    // Getters and setters
    public String getTransactionId() { return transactionId; }
    public void setStatus(String status) { this.status = status; }
    // ... other getters and setters
}