<%--
  Created by IntelliJ IDEA.
  User: MSI
  Date: 5/16/2025
  Time: 11:35 AM
  To change this template use File | Settings | File Templates.
--%>
<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<%@ page import="com.fooddelivery.billing.BillingDetails" %>
<%
    BillingDetails record = (BillingDetails) request.getAttribute("record");
%>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Billing Details</title>
</head>
<body>
<h2>Edit Billing Details</h2>

<form action="../editBillingDetails" method="post">
    <input type="hidden" name="customerUserID" value="<%= record.getCustomerUserID() %>"/>

    <label>Category:</label><br>
    <input type="text" name="category" value="<%= record.getCategory() %>" required><br><br>

    <label>Food Item:</label><br>
    <input type="text" name="foodItem" value="<%= record.getFoodItem() %>" required><br><br>

    <label>Food ID:</label><br>
    <input type="text" name="foodID" value="<%= record.getFoodID() %>" required><br><br>

    <label>Quantity:</label><br>
    <input type="number" name="quantity" value="<%= record.getQuantity() %>" required><br><br>

    <label>Total Price:</label><br>
    <input type="text" name="totalPrice" value="<%= record.getTotalPrice() %>" required><br><br>

    <input type="submit" value="Update Billing">
</form>
</body>
</html>
