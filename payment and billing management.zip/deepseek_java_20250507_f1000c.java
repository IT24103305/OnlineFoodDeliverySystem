package com.fooddelivery.payment;

public class PaymentMethod {
    private String methodId;
    private String customerId;
    private String type; // "CREDIT_CARD", "DEBIT_CARD", "E_WALLET", "COD"
    private String details;
    private boolean isDefault;

    // Constructor, getters, and setters
    public PaymentMethod(String methodId, String customerId, String type, String details, boolean isDefault) {
        this.methodId = methodId;
        this.customerId = customerId;
        this.type = type;
        this.details = details;
        this.isDefault = isDefault;
    }

    // Getters and setters for all fields
    public String getMethodId() { return methodId; }
    public void setMethodId(String methodId) { this.methodId = methodId; }
    // ... other getters and setters
}