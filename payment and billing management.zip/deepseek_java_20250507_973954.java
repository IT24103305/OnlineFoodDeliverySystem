package com.fooddelivery.payment;

import java.util.Date;
import java.util.List;

public class Invoice {
    private String invoiceId;
    private String transactionId;
    private String customerId;
    private List<OrderItem> items;
    private double totalAmount;
    private Date issueDate;
    private String status; // "GENERATED", "SENT", "PAID", "OVERDUE"

    public Invoice(String invoiceId, String transactionId, String customerId, 
                 List<OrderItem> items, double totalAmount, Date issueDate, String status) {
        this.invoiceId = invoiceId;
        this.transactionId = transactionId;
        this.customerId = customerId;
        this.items = items;
        this.totalAmount = totalAmount;
        this.issueDate = issueDate;
        this.status = status;
    }

    // Getters and setters
    public String getInvoiceId() { return invoiceId; }
    // ... other getters and setters
}