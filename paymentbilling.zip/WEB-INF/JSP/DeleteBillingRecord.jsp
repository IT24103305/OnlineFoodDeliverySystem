<%--
  Created by IntelliJ IDEA.
  User: MSI
  Date: 5/16/2025
  Time: 12:06 PM
  To change this template use File | Settings | File Templates.
--%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Delete Billing Record</title>
</head>
<body>

<h2>Delete Billing Record</h2>

<form action="../deleteBilling" method="post">
    <label for="userId">Customer User ID:</label>
    <input type="text" id="userId" name="userId" required><br><br>

    <label for="foodId">Food ID:</label>
    <input type="text" id="foodId" name="foodId" required><br><br>

    <input type="submit" value="Delete Record">
</form>

</body>
</html>
