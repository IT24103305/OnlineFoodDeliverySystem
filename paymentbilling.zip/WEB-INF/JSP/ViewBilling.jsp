<%--
  Created by IntelliJ IDEA.
  User: MSI
  Date: 5/16/2025
  Time: 11:31 AM
  To change this template use File | Settings | File Templates.
--%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.*, com.fooddelivery.billing.BillingDetails" %>
<!DOCTYPE html>
<html>
<head>
    <title>View Billing Records</title>
</head>
<body>
<h2>Billing Records</h2>

<table border="1">
    <tr>
        <th>User ID</th>
        <th>Category</th>
        <th>Food Item</th>
        <th>Food ID</th>
        <th>Quantity</th>
        <th>Total Price</th>
    </tr>
    <%
        List<BillingDetails> billingList = (List<BillingDetails>) request.getAttribute("billingList");
        if (billingList != null) {
            for (BillingDetails record : billingList) {
    %>
    <tr>
        <td><a href="../EditBillingDetails?customerUserID=<%= record.getCustomerUserID() %>">Edit</a></td>
        <td><a href="../deleteBilling?customerUserID=<%= record.getCustomerUserID() %>"
               onclick="return confirm('Are you sure you want to delete this billing record?');">
            Delete</a></td>
        <td><%= record.getCustomerUserID() %></td>
        <td><%= record.getCategory() %></td>
        <td><%= record.getFoodItem() %></td>
        <td><%= record.getFoodID() %></td>
        <td><%= record.getQuantity() %></td>
        <td><%= record.getTotalPrice() %></td>
    </tr>
    <%
        }
    } else {
    %>
    <tr><td colspan="6">No billing records found.</td></tr>
    <%
        }
    %>
</table>
</body>
</html>
