<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <title>Add Payment</title>
    <style>
        /* Full page background image of food */
        body {
            margin: 0;
            height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: url('https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=1470&q=80') no-repeat center center fixed;
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        /* Form container with translucent background */
        .payment-form {
            background: rgba(255, 255, 255, 0.85);
            padding: 30px 40px;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.3);
            width: 380px;
        }

        .payment-form h2 {
            text-align: center;
            margin-bottom: 25px;
            color: #333;
            font-weight: 700;
        }

        label {
            display: block;
            margin: 15px 0 6px;
            font-weight: 600;
            color: #555;
        }

        input[type="text"],
        input[type="number"],
        input[type="date"],
        select {
            width: 100%;
            padding: 10px 12px;
            border: 1.8px solid #ddd;
            border-radius: 6px;
            font-size: 1rem;
            transition: border-color 0.3s ease;
        }

        input[type="text"]:focus,
        input[type="number"]:focus,
        input[type="date"]:focus,
        select:focus {
            border-color: #ff6347; /* tomato color on focus */
            outline: none;
        }

        button {
            margin-top: 25px;
            width: 100%;
            background-color: #ff6347; /* tomato */
            color: white;
            padding: 12px;
            font-size: 1.1rem;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #e5533d;
        }

    </style>
</head>
<body>

<div class="payment-form">
    <h2>Add Payment</h2>

    <form action="ProcessPaymentServlet" method="post">
        <label for="orderId">Order ID:</label>
        <input type="text" id="orderId" name="orderId" required />

        <label for="paymentType">Payment Type:</label>
        <select id="paymentType" name="paymentType" required>
            <option value="">--Select Payment Type--</option>
            <option value="Credit Card">Credit Card</option>
            <option value="Debit Card">Debit Card</option>
            <option value="PayPal">PayPal</option>
            <option value="Cash On Delivery">Cash On Delivery</option>
        </select>

        <label for="amount">Amount (USD):</label>
        <input type="number" step="0.01" id="amount" name="amount" required />

        <label for="paymentDate">Payment Date:</label>
        <input type="date" id="paymentDate" name="paymentDate" required />

        <button type="submit">Add Payment</button>
    </form>
</div>

</body>
</html>
