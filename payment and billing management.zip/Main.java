public class Main {
    public static void main(String[] args) {
        // Initialize payment service
        PaymentService paymentService = new PaymentService();
        
        // Add payment methods
        PaymentMethod creditCard = new PaymentMethod(
            "PM-001", "CUST-001", "CREDIT_CARD", 
            "VISA **** 4242, Exp 05/25", true
        );
        paymentService.addPaymentMethod(creditCard);
        
        // Create an order
        Order order = new Order("ORD-001", "CUST-001", List.of(
            new OrderItem("ITEM-001", "Burger", 2, 5.99),
            new OrderItem("ITEM-002", "Fries", 1, 2.99)
        ), 14.97);
        
        // Process payment
        try {
            Transaction transaction = paymentService.processPayment(order, "PM-001");
            System.out.println("Payment successful! Transaction ID: " + transaction.getTransactionId());
            
            // Get invoice
            Invoice invoice = paymentService.getInvoicesForCustomer("CUST-001").get(0);
            System.out.println("Invoice generated: " + invoice.getInvoiceId());
            
        } catch (PaymentProcessingException e) {
            System.err.println("Payment failed: " + e.getMessage());
        }
    }
}